package testcase;

import java.io.File;
import java.io.IOException;
import java.sql.Date;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.testng.annotations.Test;

import base.BaseTest;

public class MyFirstTest extends BaseTest{
	@Test
public static void open() throws InterruptedException, IOException {
		
		driver.manage().window().maximize();
	driver.findElement(By.xpath(loc.getProperty("popup_close"))).click();
	Thread.sleep(4000);
	driver.findElement(By.xpath(loc.getProperty("Search_icon"))).click();
	Thread.sleep(4000);
	driver.findElement(By.xpath(loc.getProperty("Search_box"))).sendKeys("car");
	Thread.sleep(4000);
	driver.findElement(By.xpath(loc.getProperty("Search_button"))).click();
	Thread.sleep(4000);
	System.out.println("Test cases is successfully verified");
	File screenshotFile=((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
	FileUtils.copyFile(screenshotFile, new File("C:\\javapresentation\\Framework\\src\\test\\resources\\screenshot.png"));
	}
	
  
}
